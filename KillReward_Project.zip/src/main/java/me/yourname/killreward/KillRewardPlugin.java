package me.yourname.killreward;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class KillRewardPlugin extends JavaPlugin implements Listener {

    private static Economy economy;
    private double percent = 0.25; 
    private double minPayout = 0.01;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfig();
        if (!setupEconomy()) {
            getLogger().severe("Vault or an economy plugin not found. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("KillRewardPlugin enabled. Percent = " + (percent * 100) + "%");
    }

    private void loadConfig() {
        FileConfiguration cfg = getConfig();
        percent = cfg.getDouble("percent", 0.25);
        minPayout = cfg.getDouble("min-payout", 0.01);
        if (percent < 0) percent = 0;
        if (percent > 1) percent = 1;
        if (minPayout < 0) minPayout = 0.01;
    }

    private boolean setupEconomy() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) return;
        if (victim.equals(killer)) return;

        double victimBalance = economy.getBalance(victim);
        double rawAmount = victimBalance * percent;

        BigDecimal bd = BigDecimal.valueOf(rawAmount).setScale(2, RoundingMode.HALF_UP);
        double amount = bd.doubleValue();

        if (amount < minPayout) {
            killer.sendMessage("§eNo reward: victim balance too low.");
            return;
        }

        boolean withdrew = economy.withdrawPlayer(victim, amount).transactionSuccess();
        if (!withdrew) {
            double available = economy.getBalance(victim);
            if (available < 0.01) {
                killer.sendMessage("§eNo reward: victim has insufficient balance.");
                return;
            }
            double fallbackAmount = Math.min(amount, available);
            bd = BigDecimal.valueOf(fallbackAmount).setScale(2, RoundingMode.HALF_UP);
            amount = bd.doubleValue();
            economy.withdrawPlayer(victim, amount);
        }

        economy.depositPlayer(killer, amount);

        String formatted = String.format("%.2f", amount);
        killer.sendMessage("§aYou received §6" + formatted + "§a (" + (int)(percent*100) + "% of victim).");
        victim.sendMessage("§cYou lost §6" + formatted + "§c for being killed.");
    }
}
